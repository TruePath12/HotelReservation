package service;

import model.Customer;
import model.IRoom;
import model.Reservation;
import model.Room;
import model.RoomType;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class HotelService {
    private static final HotelService INSTANCE = new HotelService();
    private Map<String, IRoom> rooms = new HashMap<>();
    private List<Reservation> reservations = new ArrayList<>();

    private HotelService() {
    }

    public static HotelService getInstance() {
        return INSTANCE;
    }

    public void addRoom(IRoom room) {
        rooms.put(room.getRoomNumber(), room);
    }

    public IRoom getRoom(String roomId) {
        return rooms.get(roomId);
    }

    public Collection<IRoom> getAllRooms() {
        return rooms.values();
    }

    public Reservation bookRoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {
        Reservation reservation = new Reservation(customer, room, checkInDate, checkOutDate);
        reservations.add(reservation);
        return reservation;
    }

    public Collection<Reservation> getCustomersReservations(String customerEmail) {
        return reservations.stream()
                .filter(r -> r.getCustomer().getEmail().equals(customerEmail))
                .collect(Collectors.toList());
    }

    public Collection<Reservation> getAllReservations() {
        return reservations;
    }

    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate) {
        List<IRoom> availableRooms = new ArrayList<>();

        for (IRoom room : rooms.values()) {
            if (isRoomAvailable(room, checkInDate, checkOutDate)) {
                availableRooms.add(room);
            }
        }
        return availableRooms;
    }

    private boolean isRoomAvailable(IRoom room, Date checkInDate, Date checkOutDate) {
        // Check if any reservation for this room overlaps with the requested dates
        for (Reservation reservation : reservations) {
            if (reservation.getRoom().equals(room)) {
                Date resCheckIn = reservation.getCheckInDate();
                Date resCheckOut = reservation.getCheckOutDate();

                // Check for overlap
                // Overlap exists if (ReqCheckIn < ResCheckOut) AND (ReqCheckOut > ResCheckIn)
                if (checkInDate.before(resCheckOut) && checkOutDate.after(resCheckIn)) {
                    return false;
                }
            }
        }
        return true;
    }
}
