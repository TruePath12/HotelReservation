import api.HotelResource;
import model.IRoom;
import model.Reservation;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Scanner;

public class MainMenu {
    private static final HotelResource hotelResource = HotelResource.getInstance();
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

    public static void start() {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\nWelcome to the Hotel Reservation Application");
            System.out.println("----------------------------------------");
            System.out.println("1. Find and reserve a room");
            System.out.println("2. See my reservations");
            System.out.println("3. Create an account");
            System.out.println("4. Admin");
            System.out.println("5. Exit");
            System.out.println("----------------------------------------");
            System.out.print("Please select a number for the menu option: ");

            int choice;
            try {
                String line = scanner.nextLine();
                if (line.isEmpty())
                    continue;
                choice = Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    findAndReserveRoom(scanner);
                    break;
                case 2:
                    seeMyReservations(scanner);
                    break;
                case 3:
                    createAccount(scanner);
                    break;
                case 4:
                    AdminMenu.start();
                    break;
                case 5:
                    running = false;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
        scanner.close();
    }

    private static void findAndReserveRoom(Scanner scanner) {
        System.out.println("Enter Check-In Date (dd/MM/yyyy):");
        Date checkIn = getDateInput(scanner);
        if (checkIn == null)
            return;

        System.out.println("Enter Check-Out Date (dd/MM/yyyy):");
        Date checkOut = getDateInput(scanner);
        if (checkOut == null)
            return;

        Collection<IRoom> rooms = hotelResource.findARoom(checkIn, checkOut);
        if (rooms.isEmpty()) {
            System.out.println("No rooms found.");
        } else {
            System.out.println("Available Rooms:");
            for (IRoom room : rooms) {
                System.out.println(room);
            }

            System.out.println("Would you like to book a room? (y/n)");
            String bookChoice = scanner.nextLine();
            if ("y".equalsIgnoreCase(bookChoice)) {
                System.out.println("Do you have an account? (y/n)");
                String hasAccount = scanner.nextLine();

                String email;
                if ("y".equalsIgnoreCase(hasAccount)) {
                    System.out.println("Enter Email:");
                    email = scanner.nextLine();
                } else {
                    System.out.println("You need an account to book. Creating one now...");
                    email = createAccount(scanner);
                }

                if (email != null) {
                    System.out.println("Enter Room Number to book:");
                    String roomNumber = scanner.nextLine();
                    IRoom roomToBook = hotelResource.getRoom(roomNumber);

                    if (roomToBook != null) {
                        // Verify availability again? The list 'rooms' showed what was available.
                        // For simplicity, we assume user picks one from the list.
                        Reservation r = hotelResource.bookARoom(email, roomToBook, checkIn, checkOut);
                        if (r != null) {
                            System.out.println("Reservation created successfully!");
                            System.out.println(r);
                        } else {
                            System.out.println("Reservation failed. Room might be taken or customer invalid.");
                        }
                    } else {
                        System.out.println("Invalid Room Number.");
                    }
                }
            }
        }
    }

    private static void seeMyReservations(Scanner scanner) {
        System.out.println("Enter Email:");
        String email = scanner.nextLine();
        Collection<Reservation> reservations = hotelResource.getCustomersReservations(email);
        if (reservations.isEmpty()) {
            System.out.println("No reservations found.");
        } else {
            for (Reservation r : reservations) {
                System.out.println(r);
            }
        }
    }

    private static String createAccount(Scanner scanner) {
        System.out.println("Enter Email:");
        String email = scanner.nextLine();
        System.out.println("Enter First Name:");
        String firstName = scanner.nextLine();
        System.out.println("Enter Last Name:");
        String lastName = scanner.nextLine();

        try {
            hotelResource.createACustomer(email, firstName, lastName);
            System.out.println("Account created successfully!");
            return email;
        } catch (IllegalArgumentException e) {
            System.out.println("Error creating account: " + e.getMessage());
            return null;
        }
    }

    private static Date getDateInput(Scanner scanner) {
        try {
            String dateString = scanner.nextLine();
            return dateFormat.parse(dateString);
        } catch (ParseException e) {
            System.out.println("Invalid date format.");
            return null;
        }
    }
}
