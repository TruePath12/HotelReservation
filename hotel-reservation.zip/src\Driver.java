import model.Customer;

public class Driver {
    public static void main(String[] args) {
        // Valid case
        Customer customer = new Customer("first", "second", "j@domain.com");
        System.out.println(customer);

        // Invalid case - should throw IllegalArgumentException
        System.out.println("Testing invalid email...");
        Customer invalidCustomer = new Customer("first", "second", "email");
        System.out.println(invalidCustomer);
    }
}
